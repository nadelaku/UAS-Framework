<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
Content Di sini untuk Home Admin
<?= $this->endSection('content'); ?>